package sk.tuke.kpi.kp.blockpuzzle;

import sk.tuke.kpi.kp.blockpuzzle.game.ConsoleUI;

public class Bpuzzle {
    public static void main(String[] args) {
        ConsoleUI ui = new ConsoleUI();
        ui.start();
    }
}