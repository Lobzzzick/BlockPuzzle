package sk.tuke.kpi.kp.blockpuzzle.block;


public enum BlockState {
    FIXED,
    IDLE,
    SELECTED
}
