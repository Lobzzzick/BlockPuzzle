package sk.tuke.kpi.kp.blockpuzzle.field;


public class Stone {
    private int color;

    public Stone(int color) {
        this.color = color;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }
}