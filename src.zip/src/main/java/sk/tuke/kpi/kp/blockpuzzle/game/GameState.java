package sk.tuke.kpi.kp.blockpuzzle.game;

public enum GameState {
    ENDEND,
    PLAYING
}